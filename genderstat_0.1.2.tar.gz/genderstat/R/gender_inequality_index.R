##' Gender Inequality Index (GII)
#'
#' Computes the Gender Inequality Index (GII) based on the provided dataset.
#'
#' @param data A data frame containing the required metrics for GII computation.
#'
#' @return A numeric vector representing the GII values.
#'
#' @examples
#' \dontrun{
#' data(gender_inequality_index_data) # Load example dataset
#' gii_results <- gender_inequality_index(gender_inequality_index_data)
#' print(gii_results)
#' }
#'
#' @export
gender_inequality_index <- function(data) {
  ...
}


#' Simulated Data for Gender Inequality Index (GII)
#'
#' A dataset containing simulated values for the GII analysis.
#'
#' @format A data frame with 200 rows and 6 columns:
#' \describe{
#'   \item{country}{A character vector representing the name of the country.}
#'   \item{maternal_mortality_ratio}{Maternal Mortality Ratio.}
#'   \item{adolescent_birth_rate}{Adoloscent Birth rate.}
#'   \item{female_parliament_seats}{Female Parliament Seats.}
#'   \item{female_secondary_education}{Female Secondary Education.}
#'   \item{male_secondary_education}{Male Secondary Education.}
#'   \item{female_labor_force}{Participation of female in labour force.}
#'   \item{male_labor_force}{Participation of male in labour force.}
#'
#'   }
#' @source The dataset is simulated for the purpose of this package.
#' @name simulated_data_GII
#' @docType data
#' @usage data(simulated_data_GII)
NULL

############################################################################

gender_inequality_index <- function(data) {
  # Check input data for required columns
  required_columns <- c("maternal_mortality_ratio", "adolescent_birth_rate",
                        "female_parliament_seats", "female_secondary_education",
                        "male_secondary_education", "female_labor_force", "male_labor_force")
  if (!all(required_columns %in% colnames(data))) {
    stop("The input data must contain the required columns for GII calculation.")
  }

  # Calculate GII components
  H <- data$maternal_mortality_ratio / (data$maternal_mortality_ratio + data$adolescent_birth_rate)
  E <- data$female_parliament_seats * data$female_secondary_education / (data$female_secondary_education + data$male_secondary_education)
  L <- data$female_labor_force / (data$female_labor_force + data$male_labor_force)

  # Calculate GII
  GII <- 1 - (H * E * L)^(1/3)

  return(GII)
}


