# genderstat 0.1.3

## CRAN resubmission

### Changes

- Modified the `DESCRIPTION` file to address CRAN feedback:
  - Added reference(s) as prescribed.
  - removed the \dontrun{} and included the examples, and a vignettes folder with some examples.
  - ensured that your functions do not write by default, removed such functions from inst folder. 
