# genderstat 0.1.5

## CRAN resubmission

### Changes

- Modified the `DESCRIPTION` file to update the package:
  - Included DOI of the dataset used as example.
  
