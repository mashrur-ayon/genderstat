## ----setup, include=FALSE-----------------------------------------------------
library(genderstat)

#Load Example data given in the package

data("real_data_GPG")
data("real_data_GII")

gpg_results <- gender_pay_gap(real_data_GPG)
head(gpg_results)

#Calculate the Gender Inequality Index (GII)

gii_results <- gender_inequality_index(real_data_GII)
head(gii_results)


