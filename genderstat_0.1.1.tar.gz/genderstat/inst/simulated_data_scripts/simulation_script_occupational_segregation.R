

###################################
# Set the seed for reproducibility
set.seed(123)
##########################
# Generate simulated data for Occupational Segregation
##########################
##################################

# Sample occupations
occupations <- c("Engineer", "Doctor", "Teacher", "Nurse", "Lawyer", "Programmer",
                 "Designer", "Manager", "Clerk", "Salesperson")

simulated_data_OS <- data.frame(
  occupation = rep(occupations, each = 20), # 10 hypothetical occupations repeated 20 times

  # Number of men in each occupation (generally ranges between 10 to 1000 for this simulation)
  male_count = runif(200, 10, 1000),

  # Number of women in each occupation (generally ranges between 10 to 1000 for this simulation)
  female_count = runif(200, 10, 1000)
)

###############################################################################
# View the first few rows of the data frame
head(simulated_data_OS)

save(simulated_data_OS, file="data/occupational_segregation.RData")


# Test the Occupational Segregation function
#occupational_segregation(simulated_data_OS)
